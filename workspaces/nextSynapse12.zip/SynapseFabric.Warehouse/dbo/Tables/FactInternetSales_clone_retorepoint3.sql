CREATE TABLE [dbo].[FactInternetSales_clone_retorepoint3] (

	[ProductKey] varchar(8000) NULL, 
	[SalesOrderNumber] varchar(8000) NULL, 
	[CustomerPONumber] varchar(8000) NULL, 
	[OrderQuantity] float NULL, 
	[UnitPrice] float NULL, 
	[SalesAmount] float NULL
);

